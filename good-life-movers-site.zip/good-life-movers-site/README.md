# Good Life Movers Website

Luxury multi-page static website for Good Life Movers in Dubai.

## Pages

- Home
- Six service pages
- Ten location pages
- Blog hub and two SEO articles
- About and contact pages

## Lead form

Forms include Netlify Forms attributes and work automatically when deployed to Netlify. On local preview, the interface validates the fields and displays a success state without sending data.

## SEO

Each page includes unique title, description, canonical URL, Open Graph tags and schema markup. Update the `https://www.goodlifemovers.ae` canonical domain in `work/build-site.mjs` if the final production domain differs.
